
#include <iostream>

using namespace std;

//Avatar's Position
struct coordinate
  {
  int x;
  int y;
  };

class collectable
{
    //position of object
    coordinate c;

    //Whether collectable gives pacman a superpower
    bool super;

    //Score value of collectable
    int value;

    //Object dissappears when collected
    bool collected;

};

class avatar
{
  //The lives the avatar has
  int livecount;
  //Whether or not the avatar can eat the ghosts
  bool superpower;
  //increases as he gathers collectables
  int score;

  //Avatar's position
  coordinate c;

  //checks the avatars movement
  void movement (int direction, coordinate c);

  //Enables supermode if avatar takes collectable
  void enableSuperMode(collectable c);

  //Decreases Life count upon interaction with enemy
  void loselife ();

  bool getSuperpower();

  int getScore();

  int getLivecount();

};

class enemyGhost
{
    //Enemy's position
    coordinate c;

    //One life as he dissapears if eaten by avatar
    bool alive;

    //how fast the
    int speed;

    //Number of blocks where ghosts can start following avatar
    int range;

    //if superpower is on ghosts run away from avatar
    //if superpower is off ghosts attack pacman if hes in range
    void movement (bool superpower);

    //Revives ghost after a small period of time
    void revive ();

};


